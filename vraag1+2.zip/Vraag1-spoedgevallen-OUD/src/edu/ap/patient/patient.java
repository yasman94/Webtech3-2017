package edu.ap.patient;

import org.restlet.Component;
import org.restlet.data.Protocol;


public class patient {
	
	public static void main(String[] args) {
		try {
		    Component component = new Component();
		    
		    component.getServers().add(Protocol.HTTP, 8080);
		    component.getDefaultHost().attach("/ziekenhuis", new PatientApplication());
			component.start();
		} 
	    catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
